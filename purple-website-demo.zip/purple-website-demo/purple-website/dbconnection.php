<?php
require_once 'vendor/autoload.php'; // Ensure the "vlucas/phpdotenv" package is installed

$dotenv = Dotenv\Dotenv::createImmutable(_DIR_);
$dotenv->load();

$servername = getenv('DB_SERVER') ?: 'localhost';
$username = getenv('DB_USERNAME') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';
$dbname = getenv('DB_NAME') ?: 'login_register';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>